Evan Baker
CSC171
LAB TR 0940-1055
TA Stephen Cohen
LAB03

Assignment description: In this assignment, we created a custom class and practiced using constructors, private fields, and accessor and mutator methods.

Instructions to run:
Run the Driver program...
$ java Driver
should be sufficient.

**BONUS**
Instead of just some private fields with getters and setters, my custom class is more complex (and useful).
The TrajectoryObject class lets you set initial conditions and then launch, modeling a real world object that fires with some initial velocity from some height and travels through the air until hitting the ground.

Several additional methods were written to build this functionality.
Additionally several additional getters were added to retrieve some properties of the trajector such as flight time, range, peak height, and time to peak.

There's also a sprinkling of javadoc.


