Evan Baker
CSC171
LAB TR 0940-1055
TA Stephen Cohen
LAB05

Assignment description: In this assignment, we created several programs to practice conditionals, loops, variable and arrays, switch statements, and math.

Instructions to run:
Run LAB05_Driver...
$ java LAB05_Driver
should be sufficient.

All of the files (LAB05_Problem#) can also be called directly with command line args where applicable.
For example:
$ java LAB05_Problem1 3 7

Since all of this code is simple enough to be self explanatory, there are minimal comments.

**BONUS**
Most work is contracted out to helper methods to keep main succinct.

There is a Driver program that handles running all Problems 1-10 with default parameters. All Problem programs can be run directly as well, with and without commandline arguments.

When run from the Driver, each problem is neatly sectioned off.

Some basic error checking is in place where applicable.