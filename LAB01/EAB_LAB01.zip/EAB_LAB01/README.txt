Evan Baker
CSC171
LAB TR 0940-1055
TA Stephen Cohen
LAB01

Assignment description: In this assignment, we practiced basic Java syntax, set up a class with a single method,
used the println() function to print String outputs to the console, and used escaped characters.

Instructions to run: Run LAB01 as a Java program. No input args are necessary.
$ java LAB01
is sufficient.

**BONUS**
I defined class constants at the head of the file as final VARS according to "good style" guidelines.
I used the Date class to get the runtime date, and DateUtils to format that Date and print it.
I used String concatenation with "+" instead of statically coding my entire String outputs.
I used a foreach loop to print out my list of "favorites".
