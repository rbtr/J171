#!/bin/bash

echo 'Compiling package and tests...'
javac -cp src/ -d bin/ src/csc171/project03/controller/*.java
javac -cp src/ -d bin/ src/csc171/project03test/model/*.java
javac -cp src/ -d bin/ src/csc171/project03test/*.java