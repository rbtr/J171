#!/bin/bash

echo 'Testing...'
java -cp bin csc171.project03test.Test