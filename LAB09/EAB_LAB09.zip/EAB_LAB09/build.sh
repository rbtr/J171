#!/bin/bash

echo 'Compiling package and tests...'
javac -cp src/ -d bin/ src/csc171/lab09/*.java