#!/bin/bash

echo 'Running...'
java -cp bin csc171.lab09.Driver