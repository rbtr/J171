#!/bin/bash

echo 'Compiling package and tests...';
javac -cp src/ -d bin/ src/csc171/project01/blackjack/*.java;
javac -cp src/ -d bin/ test/csc171/project01/blackjack/*.java;