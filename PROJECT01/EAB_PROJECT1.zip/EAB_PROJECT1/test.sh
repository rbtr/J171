#!/bin/bash

echo 'Playing game...';
java -cp bin csc171.project01.blackjack.Test_All;