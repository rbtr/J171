Evan Baker
CSC171
LAB TR 0940-1055
TA Stephen Cohen
LAB04

Assignment description: In this assignment, we created a simple program that asked the user questions requiring either a String or numeric answer and then provide feedback. The idea was to practice if-else, boolean expressions, and comparators.

Instructions to run:
Run LAB04…
$ java LAB04
should be sufficient.

**BONUS**
Instead of static question progression, I:
Created a nested class called QuestionAndAnswer with private fields for question and answer, with getters for those. 
Created a nested class called MustangQuestions, which holds several question and answer sets and initializes an array of QuestionAndAnswer objects from those data sets. This class has an askQuestion method which handles the I/O for asking a question, getting the answer, evaluating the answer, and providing user feedback. Additionally, it asks questions randomly.
Contained the questioning logic in a do-while loop to run continuously until the user chooses to exit.

I also: 
Passed the Scanner instead of making a new one for memory efficiency (not that a Scanner is heavy, but for it’s good practice).
Wrapped the Scanner#next() and Scanner#nextDouble() calls in a try-catch to suppress the Exception output when the input is the wrong type and the scanner exits...but the program still exits.
 
There's also a sprinkling of javadoc.


