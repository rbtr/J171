#!/bin/bash

echo 'Running \products\Driver...';
java -cp bin csc171.lab06.products.Driver;