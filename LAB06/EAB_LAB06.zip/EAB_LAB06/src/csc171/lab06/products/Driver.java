package csc171.lab06.products;

/**
 * Driver.java
 * 
 * Version 1.0 
 * Copyright Evan Baker
 * Course: CSC 171 SPRING 2015 
 * Assignment: LAB 06
 * Author: Evan Baker
 * Lab Session: TR 0940-1055
 * Lab TA: Stephen Cohen 
 * Last Revised: 2/28/15
 */

class Driver {
	public static void main(String[] args) {
		System.out.println(new Product("TestProd", "TestSerial", 13.37));
	}
}