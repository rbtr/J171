#!/bin/bash

echo 'Running...'
java -cp bin/production/EAB_LAB10 csc171.lab10.Driver