#!/bin/bash

echo 'Testing...'
java -cp bin csc171.lab08.tests.Lab08Test