Evan Baker
CSC171
LAB TR 0940-1055
TA Stephen Cohen
LAB02

Assignment description: In this assignment, we practiced using the Scanner java utility, reading user input, command line arguments, proper numerical typing, and operator precedence.

! My files are always going to be named as 
LAB##_#
   \   \ 
    \   Part Number
     Lab number

Instructions to run - there are two methods:
Method 1
Run LAB02_0_DRIVER with no input arguments as
$ java LAB02_0_DRIVER

Method 2
Run each part of the Lab individually, some with args, some without.
$ java LAB02_1
$ java LAB02_2
$ java LAB02_3 degreesCelcius
$ java LAB02_4 longSeconds
$ java LAB02_5

**BONUS**
I wrote a DRIVER to run the entire Lab at one that handles getting input for the Parts that require command line arguments (Those parts can also be run as described in Method 2 above, with explicit command line arguments).

Wherever possible, such as in Part 5, I contracted work out to helper methods to keep main() succinct.
