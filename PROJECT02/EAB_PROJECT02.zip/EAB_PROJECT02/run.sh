#!/bin/bash

echo 'Running...'
java -cp bin csc171.project02.Main